import { createClient } from '@/lib/supabase/server'
import ShieldtagClient from '@/components/modules/shieldtag/shieldtag-client'

export default async function ShieldtagPage() {
  const supabase = await createClient()
  const { data: tags } = await supabase
    .from('shieldtag').select('*').is('voided_at', null)
    .order('created_at', { ascending: false }).limit(100)
  return <ShieldtagClient initialTags={tags ?? []} />
}
