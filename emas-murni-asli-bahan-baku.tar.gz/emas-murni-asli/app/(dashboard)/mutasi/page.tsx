import { createClient } from '@/lib/supabase/server'
import MutasiClient from '@/components/modules/mutasi/mutasi-client'

export default async function MutasiPage() {
  const supabase = await createClient()
  const [{ data: mutasi }, { data: cabang }, { data: stok }] = await Promise.all([
    supabase.from('mutasi').select('*').is('voided_at', null).order('created_at', { ascending: false }),
    supabase.from('cabang').select('kode, nama').eq('aktif', true),
    supabase.from('shieldtag').select('kode, gramasi, status').eq('status', 'Aktif')
  ])
  return <MutasiClient initialMutasi={mutasi ?? []} cabang={cabang ?? []} stokAktif={stok ?? []} />
}
