import { createClient } from '@/lib/supabase/server'
import InventoryClient from '@/components/modules/inventory/inventory-client'

export default async function InventoryPage() {
  const supabase = await createClient()
  const [{ data: gudang }, { data: cabang }] = await Promise.all([
    supabase.from('shieldtag').select('gramasi, status, lokasi').eq('status', 'Aktif'),
    supabase.from('shieldtag').select('gramasi, status, lokasi').eq('status', 'Terdistribusi')
  ])
  return <InventoryClient gudangData={gudang ?? []} cabangData={cabang ?? []} />
}
