import { createClient } from '@/lib/supabase/server'
import ProduksiClient from '@/components/modules/produksi/produksi-client'

export default async function ProduksiPage() {
  const supabase = await createClient()
  const [{ data: items }, { data: batches }] = await Promise.all([
    supabase.from('produksi_item').select('*, produksi_event(*)').is('voided_at', null).order('created_at', { ascending: false }),
    supabase.from('batch').select('kode, timbangan_akhir, sisa_fisik').is('voided_at', null).order('created_at', { ascending: false })
  ])
  return <ProduksiClient initialItems={items ?? []} batches={batches ?? []} />
}
