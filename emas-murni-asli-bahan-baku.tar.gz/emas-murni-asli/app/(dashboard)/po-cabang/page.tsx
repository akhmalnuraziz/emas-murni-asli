import { createClient } from '@/lib/supabase/server'
import POCabangClient from '@/components/modules/po-cabang/po-cabang-client'

export default async function POCabangPage() {
  const supabase = await createClient()
  const [{ data: po }, { data: cabang }] = await Promise.all([
    supabase.from('po_toko').select('*').is('voided_at', null).order('created_at', { ascending: false }),
    supabase.from('cabang').select('kode, nama').eq('aktif', true)
  ])
  return <POCabangClient initialPO={po ?? []} cabang={cabang ?? []} />
}
