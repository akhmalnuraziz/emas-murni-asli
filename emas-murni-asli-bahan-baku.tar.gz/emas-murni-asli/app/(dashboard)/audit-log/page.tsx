import { createClient } from '@/lib/supabase/server'
import AuditLogClient from '@/components/modules/audit-log/audit-log-client'

export default async function AuditLogPage() {
  const supabase = await createClient()
  const { data: logs } = await supabase
    .from('audit_log').select('*')
    .order('timestamp', { ascending: false }).limit(200)
  return <AuditLogClient initialLogs={logs ?? []} />
}
