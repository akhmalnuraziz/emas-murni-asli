import { createClient } from '@/lib/supabase/server'
import PenjualanClient from '@/components/modules/penjualan/penjualan-client'

export default async function PenjualanPage() {
  const supabase = await createClient()
  const [{ data: penjualan }, { data: stok }, { data: cabang }] = await Promise.all([
    supabase.from('penjualan').select('*').order('created_at', { ascending: false }).limit(100),
    supabase.from('shieldtag').select('kode, gramasi, hpp, status').eq('status', 'Aktif'),
    supabase.from('cabang').select('kode, nama').eq('aktif', true)
  ])
  return <PenjualanClient initialPenjualan={penjualan ?? []} stokAktif={stok ?? []} cabang={cabang ?? []} />
}
