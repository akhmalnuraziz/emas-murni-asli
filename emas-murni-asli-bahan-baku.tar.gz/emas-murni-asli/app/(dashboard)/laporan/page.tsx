import { createClient } from '@/lib/supabase/server'
import LaporanClient from '@/components/modules/laporan/laporan-client'

export default async function LaporanPage() {
  const supabase = await createClient()
  const [{ data: penjualan }, { data: produksi }, { data: mutasi }] = await Promise.all([
    supabase.from('penjualan').select('tanggal, gramasi, pcs, harga_jual, hpp_total, profit, source').order('tanggal', { ascending: false }).limit(200),
    supabase.from('produksi_item').select('gramasi, pcs, current_status, created_at').is('voided_at', null),
    supabase.from('mutasi').select('tanggal, pcs, total_gram, cabang_tujuan, status_kirim').is('voided_at', null)
  ])
  return <LaporanClient penjualan={penjualan ?? []} produksi={produksi ?? []} mutasi={mutasi ?? []} />
}
