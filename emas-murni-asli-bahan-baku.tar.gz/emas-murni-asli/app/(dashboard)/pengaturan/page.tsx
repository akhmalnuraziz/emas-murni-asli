import { createClient } from '@/lib/supabase/server'
import PengaturanClient from '@/components/modules/pengaturan/pengaturan-client'

export default async function PengaturanPage() {
  const supabase = await createClient()
  const [{ data: users }, { data: cabang }] = await Promise.all([
    supabase.from('users_profile').select('*').is('voided_at', null).order('created_at', { ascending: false }),
    supabase.from('cabang').select('*').is('voided_at', null).order('created_at', { ascending: false })
  ])
  return <PengaturanClient initialUsers={users ?? []} initialCabang={cabang ?? []} />
}
