'use client'
import { useState } from 'react'
import { Warehouse, BarChart3 } from 'lucide-react'
import { GRAMASI_OPTIONS } from '@/lib/types/database'

export default function InventoryClient({ gudangData, cabangData }: { gudangData: any[], cabangData: any[] }) {
  const [view, setView] = useState<'gudang' | 'cabang'>('gudang')

  const summarize = (data: any[]) => {
    const map: Record<string, number> = {}
    data.forEach(d => { if (d.gramasi) map[d.gramasi] = (map[d.gramasi] || 0) + 1 })
    return GRAMASI_OPTIONS.filter(g => map[g]).map(g => ({ gramasi: g, pcs: map[g] }))
  }

  const cabangSummary = () => {
    const map: Record<string, Record<string, number>> = {}
    cabangData.forEach(d => {
      const loc = d.lokasi || 'Cabang'
      if (!map[loc]) map[loc] = {}
      if (d.gramasi) map[loc][d.gramasi] = (map[loc][d.gramasi] || 0) + 1
    })
    return map
  }

  const gudangSummary = summarize(gudangData)

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Stok Gudang Pusat', value: gudangData.length },
          { label: 'Stok Terdistribusi', value: cabangData.length },
          { label: 'Total Stok', value: gudangData.length + cabangData.length },
          { label: 'Variant Gramasi', value: gudangSummary.length },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-2xl border border-slate-100 p-4">
            <p className="text-2xl font-bold text-slate-900">{s.value.toLocaleString('id-ID')}</p>
            <p className="text-xs text-slate-500 mt-0.5 font-medium">{s.label}</p>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        {(['gudang', 'cabang'] as const).map(v => (
          <button key={v} onClick={() => setView(v)}
            className={`px-4 h-9 rounded-xl text-sm font-semibold transition-all ${view === v ? 'bg-violet-600 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>
            {v === 'gudang' ? '🏭 Gudang Pusat' : '🏪 Cabang'}
          </button>
        ))}
      </div>
      {view === 'gudang' && (
        <div className="bg-white rounded-2xl border border-slate-100 p-5">
          <h3 className="font-bold text-slate-800 mb-4">Stok Gudang per Gramasi</h3>
          {gudangSummary.length === 0 ? <p className="text-center text-slate-300 py-8">Belum ada stok aktif</p> : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {gudangSummary.map(s => (
                <div key={s.gramasi} className="bg-violet-50 border border-violet-100 rounded-xl p-4 text-center">
                  <p className="text-2xl font-bold text-violet-700">{s.pcs}</p>
                  <p className="text-xs font-semibold text-violet-500 mt-1">LM REI {s.gramasi} GR</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
      {view === 'cabang' && (
        <div className="bg-white rounded-2xl border border-slate-100 p-5">
          <h3 className="font-bold text-slate-800 mb-4">Stok per Cabang</h3>
          {Object.keys(cabangSummary()).length === 0 ? <p className="text-center text-slate-300 py-8">Belum ada stok di cabang</p> : (
            <div className="space-y-4">
              {Object.entries(cabangSummary()).map(([loc, grams]) => (
                <div key={loc} className="border border-slate-100 rounded-xl p-4">
                  <p className="font-semibold text-slate-800 mb-3">{loc}</p>
                  <div className="flex gap-2 flex-wrap">
                    {Object.entries(grams).map(([g, pcs]) => (
                      <div key={g} className="bg-blue-50 rounded-lg px-3 py-2 text-center">
                        <p className="font-bold text-blue-700">{pcs as number}</p>
                        <p className="text-[10px] text-blue-500">{g} gr</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
