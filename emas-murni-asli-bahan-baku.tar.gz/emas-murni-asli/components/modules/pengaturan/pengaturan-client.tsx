'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Users, Building2, Plus, X, Save } from 'lucide-react'
import { ROLE_LABELS, type UserRole } from '@/lib/types/database'
import { getInitials } from '@/lib/utils'

const ROLES: UserRole[] = ['owner', 'admin_pusat', 'spv', 'operator_produksi', 'gudang', 'accounting', 'kepala_cabang']

export default function PengaturanClient({ initialUsers, initialCabang }: any) {
  const [tab, setTab] = useState<'users' | 'cabang'>('users')
  const [users, setUsers] = useState(initialUsers)
  const [cabang, setCabang] = useState(initialCabang)
  const [showUserForm, setShowUserForm] = useState(false)
  const [showCabangForm, setShowCabangForm] = useState(false)
  const [loading, setLoading] = useState(false)
  const [userForm, setUserForm] = useState({ email: '', name: '', role: 'operator_produksi' as UserRole, toko: '' })
  const [cabangForm, setCabangForm] = useState({ kode: '', nama: '', alamat: '', kepala: '', telp: '' })
  const supabase = createClient()

  const handleAddCabang = async () => {
    if (!cabangForm.kode || !cabangForm.nama) return
    setLoading(true)
    const { data, error } = await supabase.from('cabang').insert({
      kode: cabangForm.kode, nama: cabangForm.nama,
      alamat: cabangForm.alamat || null, kepala: cabangForm.kepala || null,
      telp: cabangForm.telp || null, aktif: true
    }).select().single()
    if (!error && data) { setCabang([data, ...cabang]); setShowCabangForm(false) }
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        {(['users', 'cabang'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 h-9 rounded-xl text-sm font-semibold transition-all ${tab === t ? 'bg-violet-600 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>
            {t === 'users' ? '👥 Pengguna' : '🏪 Cabang'}
          </button>
        ))}
      </div>

      {tab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-100 p-5">
          <div className="flex justify-between mb-4">
            <h3 className="font-bold text-slate-800">Manajemen Pengguna</h3>
            <button onClick={() => setShowUserForm(!showUserForm)} className="flex items-center gap-2 h-8 px-3 bg-violet-600 text-white rounded-xl text-xs font-semibold">
              <Plus size={12} /> Tambah User
            </button>
          </div>
          {showUserForm && (
            <div className="mb-4 p-4 bg-violet-50 rounded-xl border border-violet-100">
              <p className="text-xs text-violet-600 font-semibold mb-3">⚠️ User baru harus didaftarkan via Supabase Auth Dashboard terlebih dahulu, lalu data profile ditambahkan di sini.</p>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Email', key: 'email', placeholder: 'user@email.com' },
                  { label: 'Nama', key: 'name', placeholder: 'Nama lengkap' },
                ].map(f => (
                  <div key={f.key}>
                    <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">{f.label}</label>
                    <input value={(userForm as any)[f.key]} onChange={e => setUserForm({ ...userForm, [f.key]: e.target.value })}
                      placeholder={f.placeholder} className="w-full h-9 px-3 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
                  </div>
                ))}
                <div>
                  <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Role</label>
                  <select value={userForm.role} onChange={e => setUserForm({ ...userForm, role: e.target.value as UserRole })}
                    className="w-full h-9 px-3 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                    {ROLES.map(r => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
                  </select>
                </div>
              </div>
              <button onClick={() => setShowUserForm(false)} className="mt-3 h-8 px-4 bg-slate-100 rounded-xl text-xs font-medium text-slate-600">Tutup</button>
            </div>
          )}
          <div className="space-y-2">
            {users.map((u: any) => (
              <div key={u.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50">
                <div className="w-9 h-9 rounded-full bg-violet-600 flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-[11px] font-bold">{getInitials(u.name)}</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-800">{u.name}</p>
                  <p className="text-xs text-slate-400">{u.email}</p>
                </div>
                <span className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-violet-50 text-violet-700">{ROLE_LABELS[u.role as UserRole]}</span>
                <span className={`text-[10px] font-semibold px-2.5 py-1 rounded-full ${u.aktif ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'}`}>{u.aktif ? 'Aktif' : 'Nonaktif'}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'cabang' && (
        <div className="bg-white rounded-2xl border border-slate-100 p-5">
          <div className="flex justify-between mb-4">
            <h3 className="font-bold text-slate-800">Manajemen Cabang</h3>
            <button onClick={() => setShowCabangForm(!showCabangForm)} className="flex items-center gap-2 h-8 px-3 bg-violet-600 text-white rounded-xl text-xs font-semibold">
              <Plus size={12} /> Tambah Cabang
            </button>
          </div>
          {showCabangForm && (
            <div className="mb-4 p-4 bg-violet-50 rounded-xl border border-violet-100">
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Kode Cabang *', key: 'kode', placeholder: 'CBG001' },
                  { label: 'Nama Cabang *', key: 'nama', placeholder: 'Cabang Jakarta' },
                  { label: 'Kepala Cabang', key: 'kepala', placeholder: 'Nama kepala' },
                  { label: 'No. Telepon', key: 'telp', placeholder: '08xxxxxxxxxx' },
                ].map(f => (
                  <div key={f.key}>
                    <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">{f.label}</label>
                    <input value={(cabangForm as any)[f.key]} onChange={e => setCabangForm({ ...cabangForm, [f.key]: e.target.value })}
                      placeholder={f.placeholder} className="w-full h-9 px-3 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
                  </div>
                ))}
              </div>
              <div className="flex gap-2 mt-3">
                <button onClick={handleAddCabang} disabled={loading}
                  className="flex items-center gap-2 h-8 px-4 bg-violet-600 text-white rounded-xl text-xs font-semibold disabled:opacity-50">
                  <Save size={12} /> {loading ? 'Menyimpan...' : 'Simpan'}
                </button>
                <button onClick={() => setShowCabangForm(false)} className="h-8 px-3 bg-slate-100 rounded-xl text-xs font-medium text-slate-600">Batal</button>
              </div>
            </div>
          )}
          <div className="space-y-2">
            {cabang.length === 0 && <p className="text-center text-slate-300 py-8">Belum ada cabang</p>}
            {cabang.map((c: any) => (
              <div key={c.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50">
                <div className="w-9 h-9 rounded-xl bg-blue-100 flex items-center justify-center">
                  <Building2 size={16} className="text-blue-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-800">{c.nama}</p>
                  <p className="text-xs text-slate-400">{c.kode} {c.kepala ? `· ${c.kepala}` : ''}</p>
                </div>
                <span className={`text-[10px] font-semibold px-2.5 py-1 rounded-full ${c.aktif ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'}`}>{c.aktif ? 'Aktif' : 'Nonaktif'}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
