'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Plus, Search, ShoppingCart, X, Save } from 'lucide-react'
import { cn, formatRupiah, formatDate } from '@/lib/utils'
import { GRAMASI_OPTIONS } from '@/lib/types/database'

const SOURCES = ['Toko', 'Shopee', 'TikTok Shop', 'Raja Emas App', 'Lainnya']

export default function PenjualanClient({ initialPenjualan, stokAktif, cabang }: any) {
  const [penjualan, setPenjualan] = useState(initialPenjualan)
  const [search, setSearch] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    source: 'Toko', toko: '', nama_customer: '', hp_customer: '',
    gramasi: '1', pcs: '1', harga_jual: '', fee_marketplace: '0',
    ongkir: '0', no_invoice_mktpl: '', catatan: '', shieldtag_kodes: ''
  })
  const supabase = createClient()

  const filtered = penjualan.filter((p: any) =>
    (p.no_faktur ?? '').toLowerCase().includes(search.toLowerCase()) ||
    (p.nama_customer ?? '').toLowerCase().includes(search.toLowerCase())
  )

  const totalProfit = () => {
    const harga = parseFloat(form.harga_jual) || 0
    const fee = parseFloat(form.fee_marketplace) || 0
    const ongkir = parseFloat(form.ongkir) || 0
    const stok = stokAktif.filter((s: any) =>
      form.shieldtag_kodes.split('\n').map((k: string) => k.trim()).includes(s.kode)
    )
    const hpp = stok.reduce((sum: number, s: any) => sum + (s.hpp || 0), 0)
    return harga - fee - ongkir - hpp
  }

  const handleSubmit = async () => {
    if (!form.nama_customer || !form.harga_jual) return
    setLoading(true)
    const kodes = form.shieldtag_kodes.split('\n').map((k: string) => k.trim()).filter(Boolean)
    const now = new Date()
    const faktur = `INV/${now.getFullYear()}/${String(now.getMonth()+1).padStart(2,'0')}${String(penjualan.length+1).padStart(5,'0')}`
    const { data, error } = await supabase.from('penjualan').insert({
      no_faktur: faktur, tanggal: now.toISOString().split('T')[0],
      source: form.source, toko: form.toko || null,
      nama_customer: form.nama_customer, hp_customer: form.hp_customer,
      gramasi: form.gramasi, pcs: parseInt(form.pcs),
      harga_jual: parseFloat(form.harga_jual),
      fee_marketplace: parseFloat(form.fee_marketplace) || 0,
      ongkir: parseFloat(form.ongkir) || 0,
      shieldtag_kodes: kodes, profit: totalProfit(),
      no_invoice_mktpl: form.no_invoice_mktpl || null,
      catatan: form.catatan, status: 'Selesai'
    }).select().single()
    if (!error && data) { setPenjualan([data, ...penjualan]); setShowForm(false) }
    setLoading(false)
  }

  const totalRevenue = penjualan.slice(0,30).reduce((s: number, p: any) => s + (p.harga_jual || 0), 0)
  const totalProfit30 = penjualan.slice(0,30).reduce((s: number, p: any) => s + (p.profit || 0), 0)

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {[
          { label: 'Total Transaksi', value: penjualan.length, fmt: false },
          { label: 'Revenue (30 terbaru)', value: totalRevenue, fmt: true },
          { label: 'Profit (30 terbaru)', value: totalProfit30, fmt: true },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-2xl border border-slate-100 p-4">
            <p className="text-xl font-bold text-slate-900">{s.fmt ? formatRupiah(s.value) : s.value}</p>
            <p className="text-xs text-slate-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari faktur, customer..."
            className="w-full pl-8 pr-3 h-9 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-violet-400" />
        </div>
        <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-2 h-9 px-4 bg-violet-600 text-white rounded-xl text-sm font-semibold">
          <Plus size={14} /> Penjualan Baru
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl border border-violet-100 p-5">
          <div className="flex justify-between mb-4">
            <h3 className="font-bold text-slate-800">Input Penjualan</h3>
            <button onClick={() => setShowForm(false)}><X size={16} className="text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Channel Penjualan</label>
              <select value={form.source} onChange={e => setForm({ ...form, source: e.target.value })}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                {SOURCES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Nama Customer *</label>
              <input value={form.nama_customer} onChange={e => setForm({ ...form, nama_customer: e.target.value })}
                placeholder="Nama lengkap" className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">No. HP Customer</label>
              <input value={form.hp_customer} onChange={e => setForm({ ...form, hp_customer: e.target.value })}
                placeholder="08xxxxxxxxxx" className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Gramasi</label>
              <select value={form.gramasi} onChange={e => setForm({ ...form, gramasi: e.target.value })}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                {GRAMASI_OPTIONS.map(g => <option key={g} value={g}>{g} gr</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Harga Jual (IDR) *</label>
              <input type="number" value={form.harga_jual} onChange={e => setForm({ ...form, harga_jual: e.target.value })}
                placeholder="1000000" className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Fee Marketplace</label>
              <input type="number" value={form.fee_marketplace} onChange={e => setForm({ ...form, fee_marketplace: e.target.value })}
                placeholder="0" className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
            </div>
            <div className="col-span-2 md:col-span-3">
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Kode Shieldtag (opsional, 1 per baris)</label>
              <textarea value={form.shieldtag_kodes} onChange={e => setForm({ ...form, shieldtag_kodes: e.target.value })}
                rows={3} placeholder="SHT-2026-00001"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono focus:outline-none focus:border-violet-400 resize-none" />
            </div>
          </div>
          {form.harga_jual && (
            <div className="mt-3 p-3 bg-green-50 rounded-xl text-sm">
              Estimasi profit: <strong className="text-green-700">{formatRupiah(totalProfit())}</strong>
            </div>
          )}
          <button onClick={handleSubmit} disabled={loading}
            className="mt-4 flex items-center gap-2 h-10 px-5 bg-violet-600 text-white rounded-xl text-sm font-semibold disabled:opacity-50">
            <Save size={14} /> {loading ? 'Menyimpan...' : 'Simpan Penjualan'}
          </button>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-100 bg-slate-50/50">
              <tr>
                {['Faktur', 'Tanggal', 'Customer', 'Source', 'Gramasi', 'Harga Jual', 'Profit'].map(h => (
                  <th key={h} className="text-left px-4 py-2.5 text-[10px] font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && <tr><td colSpan={7} className="text-center py-12 text-slate-300"><ShoppingCart size={28} className="mx-auto mb-2 opacity-30" />Belum ada penjualan</td></tr>}
              {filtered.map((p: any) => (
                <tr key={p.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                  <td className="px-4 py-2.5 font-mono text-xs font-semibold text-violet-700">{p.no_faktur}</td>
                  <td className="px-4 py-2.5 text-xs text-slate-500 whitespace-nowrap">{formatDate(p.tanggal)}</td>
                  <td className="px-4 py-2.5 font-medium text-slate-800">{p.nama_customer}</td>
                  <td className="px-4 py-2.5 text-xs text-slate-500">{p.source}</td>
                  <td className="px-4 py-2.5 font-semibold">{p.gramasi} gr</td>
                  <td className="px-4 py-2.5 font-semibold text-slate-800">{formatRupiah(p.harga_jual)}</td>
                  <td className={cn('px-4 py-2.5 font-bold', p.profit >= 0 ? 'text-green-600' : 'text-red-600')}>{formatRupiah(p.profit)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
