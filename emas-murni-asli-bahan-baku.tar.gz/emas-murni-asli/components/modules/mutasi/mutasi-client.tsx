'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Plus, Search, ArrowLeftRight, X, Save } from 'lucide-react'
import { cn, formatDate } from '@/lib/utils'
import { STATUS_BADGE_STYLES } from '@/lib/utils'

export default function MutasiClient({ initialMutasi, cabang, stokAktif }: any) {
  const [mutasi, setMutasi] = useState(initialMutasi)
  const [search, setSearch] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ cabang_tujuan: '', pic: '', catatan: '', shieldtag_kodes: '' })
  const supabase = createClient()

  const filtered = mutasi.filter((m: any) =>
    (m.kode ?? '').toLowerCase().includes(search.toLowerCase()) ||
    (m.cabang_tujuan ?? '').toLowerCase().includes(search.toLowerCase())
  )

  const handleSubmit = async () => {
    if (!form.cabang_tujuan) return
    setLoading(true)
    const kodes = form.shieldtag_kodes.split('\n').map((k: string) => k.trim()).filter(Boolean)
    const now = new Date()
    const kode = `MUT/${now.getFullYear()}/${String(now.getMonth()+1).padStart(2,'0')}${String(mutasi.length+1).padStart(4,'0')}`
    const { data, error } = await supabase.from('mutasi').insert({
      kode, tanggal: now.toISOString().split('T')[0],
      cabang_tujuan: form.cabang_tujuan, shieldtag_kodes: kodes,
      pcs: kodes.length, pic: form.pic, catatan: form.catatan,
      status_kirim: 'Belum Dikirim', status_terima: 'Belum Diterima'
    }).select().single()
    if (!error && data) { setMutasi([data, ...mutasi]); setShowForm(false) }
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari mutasi..."
            className="w-full pl-8 pr-3 h-9 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-violet-400" />
        </div>
        <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-2 h-9 px-4 bg-violet-600 text-white rounded-xl text-sm font-semibold">
          <Plus size={14} /> Mutasi Baru
        </button>
      </div>
      {showForm && (
        <div className="bg-white rounded-2xl border border-violet-100 p-5">
          <div className="flex justify-between mb-4">
            <h3 className="font-bold text-slate-800">Buat Mutasi Cabang</h3>
            <button onClick={() => setShowForm(false)}><X size={16} className="text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Cabang Tujuan *</label>
              <select value={form.cabang_tujuan} onChange={e => setForm({ ...form, cabang_tujuan: e.target.value })}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                <option value="">-- Pilih Cabang --</option>
                {cabang.map((c: any) => <option key={c.kode} value={c.kode}>{c.nama}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">PIC / Kurir</label>
              <input value={form.pic} onChange={e => setForm({ ...form, pic: e.target.value })}
                placeholder="Nama pengantar" className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
            </div>
            <div className="col-span-2">
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Kode Shieldtag (1 per baris)</label>
              <textarea value={form.shieldtag_kodes} onChange={e => setForm({ ...form, shieldtag_kodes: e.target.value })}
                placeholder="SHT-2026-00001" rows={4}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono focus:outline-none focus:border-violet-400 resize-none" />
              <p className="text-[10px] text-slate-400 mt-1">{form.shieldtag_kodes.split('\n').filter(k => k.trim()).length} shieldtag</p>
            </div>
          </div>
          <button onClick={handleSubmit} disabled={loading}
            className="mt-4 flex items-center gap-2 h-10 px-5 bg-violet-600 text-white rounded-xl text-sm font-semibold disabled:opacity-50">
            <Save size={14} /> {loading ? 'Menyimpan...' : 'Buat Mutasi'}
          </button>
        </div>
      )}
      <div className="space-y-2">
        {filtered.length === 0 && <div className="bg-white rounded-2xl border border-slate-100 py-16 text-center"><ArrowLeftRight size={32} className="text-slate-200 mx-auto mb-3" /><p className="text-slate-400 text-sm">Belum ada mutasi</p></div>}
        {filtered.map((m: any) => (
          <div key={m.id} className="bg-white rounded-2xl border border-slate-100 px-4 py-3.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-sm text-slate-800">{m.kode}</span>
              <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full border', STATUS_BADGE_STYLES[m.status_kirim as keyof typeof STATUS_BADGE_STYLES] ?? '')}>{m.status_kirim}</span>
              <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full border', STATUS_BADGE_STYLES[m.status_terima as keyof typeof STATUS_BADGE_STYLES] ?? '')}>{m.status_terima}</span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">→ {m.cabang_tujuan} · {m.pcs} pcs · {formatDate(m.tanggal)}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
