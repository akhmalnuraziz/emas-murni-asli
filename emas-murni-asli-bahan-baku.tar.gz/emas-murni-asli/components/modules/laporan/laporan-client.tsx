'use client'
import { useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts'
import { formatRupiah } from '@/lib/utils'

const COLORS = ['#7C3AED', '#8B5CF6', '#A78BFA', '#C4B5FD', '#DDD6FE', '#EDE9FE']

export default function LaporanClient({ penjualan, produksi, mutasi }: any) {
  const [tab, setTab] = useState<'penjualan' | 'produksi' | 'mutasi'>('penjualan')

  // Aggregate penjualan by date (last 30)
  const salesByDate = penjualan.slice(0, 30).reduce((acc: any, p: any) => {
    const d = p.tanggal?.slice(0, 10)
    if (!d) return acc
    if (!acc[d]) acc[d] = { tanggal: d, revenue: 0, profit: 0, pcs: 0 }
    acc[d].revenue += p.harga_jual || 0
    acc[d].profit += p.profit || 0
    acc[d].pcs += p.pcs || 1
    return acc
  }, {})
  const salesChart = Object.values(salesByDate).slice(-14)

  // Source breakdown
  const bySource = penjualan.reduce((acc: any, p: any) => {
    acc[p.source] = (acc[p.source] || 0) + 1
    return acc
  }, {})
  const sourceChart = Object.entries(bySource).map(([name, value]) => ({ name, value }))

  // Produksi by status
  const byStatus = produksi.reduce((acc: any, p: any) => {
    acc[p.current_status || 'Unknown'] = (acc[p.current_status || 'Unknown'] || 0) + (p.pcs || 0)
    return acc
  }, {})
  const statusChart = Object.entries(byStatus).map(([name, value]) => ({ name, value }))

  const totalRevenue = penjualan.reduce((s: number, p: any) => s + (p.harga_jual || 0), 0)
  const totalProfit = penjualan.reduce((s: number, p: any) => s + (p.profit || 0), 0)
  const totalPcs = penjualan.reduce((s: number, p: any) => s + (p.pcs || 0), 0)

  return (
    <div className="space-y-5">
      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Revenue', value: formatRupiah(totalRevenue), color: 'violet' },
          { label: 'Total Profit', value: formatRupiah(totalProfit), color: 'green' },
          { label: 'Total Penjualan', value: `${penjualan.length} transaksi`, color: 'blue' },
          { label: 'Total Pcs Terjual', value: `${totalPcs} pcs`, color: 'amber' },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-2xl border border-slate-100 p-4">
            <p className="text-lg font-bold text-slate-900">{s.value}</p>
            <p className="text-xs text-slate-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        {(['penjualan', 'produksi', 'mutasi'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 h-9 rounded-xl text-sm font-semibold capitalize transition-all ${tab === t ? 'bg-violet-600 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>
            {t === 'penjualan' ? '💰 Penjualan' : t === 'produksi' ? '🔨 Produksi' : '📦 Mutasi'}
          </button>
        ))}
      </div>

      {tab === 'penjualan' && (
        <div className="grid md:grid-cols-2 gap-5">
          <div className="bg-white rounded-2xl border border-slate-100 p-5">
            <h3 className="font-semibold text-slate-800 text-sm mb-4">Revenue 14 Hari Terakhir</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={salesChart}>
                <XAxis dataKey="tanggal" tick={{ fontSize: 10 }} tickFormatter={v => v.slice(5)} />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `${(v/1000000).toFixed(0)}jt`} />
                <Tooltip formatter={(v: any) => formatRupiah(Number(v))} />
                <Line type="monotone" dataKey="revenue" stroke="#7C3AED" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-white rounded-2xl border border-slate-100 p-5">
            <h3 className="font-semibold text-slate-800 text-sm mb-4">Penjualan per Channel</h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={sourceChart} dataKey="value" nameKey="name" outerRadius={80} label={({ name, percent }) => `${name} ${((percent ?? 0)*100).toFixed(0)}%`} labelLine={false}>
                  {sourceChart.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {tab === 'produksi' && (
        <div className="bg-white rounded-2xl border border-slate-100 p-5">
          <h3 className="font-semibold text-slate-800 text-sm mb-4">Produksi per Status (PCS)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={statusChart} barSize={40}>
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="value" fill="#7C3AED" radius={[6,6,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {tab === 'mutasi' && (
        <div className="bg-white rounded-2xl border border-slate-100 p-5">
          <h3 className="font-semibold text-slate-800 text-sm mb-4">Histori Mutasi</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-slate-100">
                {['Tanggal','Tujuan','PCS','Berat','Status Kirim'].map(h => (
                  <th key={h} className="text-left pb-2 text-[10px] font-bold text-slate-500 uppercase px-2">{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {mutasi.slice(0,20).map((m: any, i: number) => (
                  <tr key={i} className="border-b border-slate-50">
                    <td className="px-2 py-2 text-xs text-slate-500">{m.tanggal}</td>
                    <td className="px-2 py-2 text-sm font-medium">{m.cabang_tujuan}</td>
                    <td className="px-2 py-2 text-sm">{m.pcs}</td>
                    <td className="px-2 py-2 text-sm">{Number(m.total_gram || 0).toFixed(2)} gr</td>
                    <td className="px-2 py-2 text-xs">{m.status_kirim}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
