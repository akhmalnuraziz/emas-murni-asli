'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Plus, Search, X, Save, Hammer, ChevronDown, ChevronUp } from 'lucide-react'
import { cn, formatDate } from '@/lib/utils'
import { STATUS_BADGE_STYLES } from '@/lib/utils'
import { GRAMASI_OPTIONS } from '@/lib/types/database'
import type { StatusProduksi } from '@/lib/types/database'

const STATUS_OPTIONS: StatusProduksi[] = ['Pas Berat', 'Annealing', 'Siap Packing', 'Sudah Packing', 'Reject']

export default function ProduksiClient({ initialItems, batches }: { initialItems: any[], batches: any[] }) {
  const [items, setItems] = useState(initialItems)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('semua')
  const [showForm, setShowForm] = useState(false)
  const [expanded, setExpanded] = useState<number | null>(null)
  const [loading, setLoading] = useState(false)
  const [showUpdateModal, setShowUpdateModal] = useState<any>(null)
  const [form, setForm] = useState({
    batch_kode: '', gramasi: '1', pcs: '', catatan: '', status: 'Pas Berat' as StatusProduksi
  })
  const [updateForm, setUpdateForm] = useState({ status: 'Annealing' as StatusProduksi, total_gram: '', sisa_serbuk: '', catatan: '' })
  const supabase = createClient()

  const filtered = items.filter(i => {
    const matchSearch = i.kode?.toLowerCase().includes(search.toLowerCase()) ||
      i.batch_kode?.toLowerCase().includes(search.toLowerCase())
    const matchStatus = statusFilter === 'semua' || i.current_status === statusFilter
    return matchSearch && matchStatus
  })

  const generateKode = () => {
    const now = new Date()
    const d = now.toISOString().split('T')[0].replace(/-/g, '')
    return `PRD-${d}-${String(items.length + 1).padStart(3, '0')}`
  }

  const handleSubmit = async () => {
    if (!form.batch_kode || !form.pcs) return
    setLoading(true)
    const totalGram = parseFloat(form.gramasi) * parseInt(form.pcs)
    const kode = generateKode()
    const { data, error } = await supabase.from('produksi_item').insert({
      kode, batch_kode: form.batch_kode, gramasi: form.gramasi,
      pcs: parseInt(form.pcs), total_gram: totalGram,
      current_status: form.status, catatan: form.catatan
    }).select().single()
    if (!error && data) {
      setItems([{ ...data, produksi_event: [] }, ...items])
      setForm({ batch_kode: '', gramasi: '1', pcs: '', catatan: '', status: 'Pas Berat' })
      setShowForm(false)
    }
    setLoading(false)
  }

  const handleUpdateStatus = async () => {
    if (!showUpdateModal) return
    setLoading(true)
    const { error: evErr } = await supabase.from('produksi_event').insert({
      produksi_item_id: showUpdateModal.id,
      tanggal: new Date().toISOString().split('T')[0],
      status: updateForm.status,
      total_gram: parseFloat(updateForm.total_gram) || null,
      sisa_serbuk: parseFloat(updateForm.sisa_serbuk) || null,
      catatan: updateForm.catatan
    })
    if (!evErr) {
      await supabase.from('produksi_item').update({
        current_status: updateForm.status,
        total_gram: parseFloat(updateForm.total_gram) || showUpdateModal.total_gram
      }).eq('id', showUpdateModal.id)
      setItems(items.map(i => i.id === showUpdateModal.id
        ? { ...i, current_status: updateForm.status }
        : i))
    }
    setShowUpdateModal(null)
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari kode, batch..."
            className="w-full pl-8 pr-3 h-9 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-violet-400" />
        </div>
        <div className="flex gap-1 flex-wrap">
          {['semua', ...STATUS_OPTIONS].map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={cn('px-2.5 h-8 rounded-lg text-[11px] font-semibold capitalize transition-all',
                statusFilter === s ? 'bg-violet-600 text-white' : 'bg-white text-slate-600 border border-slate-200')}>
              {s === 'semua' ? 'Semua' : s}
            </button>
          ))}
        </div>
        <button onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 h-9 px-4 bg-violet-600 text-white rounded-xl text-sm font-semibold ml-auto">
          <Plus size={14} /> Cetak Baru
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-2xl border border-violet-100 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-800">Permintaan Cetak Baru</h3>
            <button onClick={() => setShowForm(false)}><X size={16} className="text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">Batch Bahan Baku *</label>
              <select value={form.batch_kode} onChange={e => setForm({ ...form, batch_kode: e.target.value })}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                <option value="">-- Pilih Batch --</option>
                {batches.filter(b => !b.voided_at).map(b => (
                  <option key={b.kode} value={b.kode}>
                    {b.kode} (Sisa: {Number(b.sisa_fisik ?? 0).toFixed(2)}gr)
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">Gramasi Target *</label>
              <select value={form.gramasi} onChange={e => setForm({ ...form, gramasi: e.target.value })}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                {GRAMASI_OPTIONS.map(g => <option key={g} value={g}>{g} Gram</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">Jumlah PCS *</label>
              <input type="number" value={form.pcs} onChange={e => setForm({ ...form, pcs: e.target.value })}
                placeholder="50" className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">Status Awal</label>
              <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value as StatusProduksi })}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="col-span-2">
              <label className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">Catatan / Memo Operator</label>
              <input value={form.catatan} onChange={e => setForm({ ...form, catatan: e.target.value })}
                placeholder="Keterangan mesin, shift operator..." className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
            </div>
          </div>
          {form.gramasi && form.pcs && (
            <div className="mt-3 p-3 bg-violet-50 rounded-xl text-sm text-violet-700">
              Estimasi kebutuhan: <strong>{(parseFloat(form.gramasi) * parseInt(form.pcs || '0')).toFixed(2)} gr</strong>
            </div>
          )}
          <div className="flex gap-3 mt-4">
            <button onClick={handleSubmit} disabled={loading}
              className="flex items-center gap-2 h-10 px-5 bg-violet-600 text-white rounded-xl text-sm font-semibold disabled:opacity-50">
              <Save size={14} /> {loading ? 'Menyimpan...' : 'Mulai Alur'}
            </button>
          </div>
        </div>
      )}

      {/* Status legend */}
      <div className="flex gap-2 flex-wrap">
        {STATUS_OPTIONS.map(s => (
          <span key={s} className={cn('text-[10px] font-semibold px-2.5 py-1 rounded-full border', STATUS_BADGE_STYLES[s])}>
            {s}
          </span>
        ))}
      </div>

      {/* List */}
      <div className="space-y-2">
        {filtered.length === 0 && (
          <div className="bg-white rounded-2xl border border-slate-100 py-16 text-center">
            <Hammer size={32} className="text-slate-200 mx-auto mb-3" />
            <p className="text-slate-400 text-sm">Belum ada data produksi</p>
          </div>
        )}
        {filtered.map(item => (
          <div key={item.id} className="bg-white rounded-2xl border border-slate-100">
            <div className="flex items-center gap-3 px-4 py-3.5 cursor-pointer"
              onClick={() => setExpanded(expanded === item.id ? null : item.id)}>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-sm text-slate-800">{item.kode}</span>
                  <span className="text-xs text-slate-400">{item.batch_kode}</span>
                  {item.current_status && (
                    <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full border', STATUS_BADGE_STYLES[item.current_status as StatusProduksi] ?? '')}>
                      {item.current_status}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{item.gramasi} gr × {item.pcs} pcs · {formatDate(item.created_at)}</p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={e => { e.stopPropagation(); setShowUpdateModal(item); setUpdateForm({ status: 'Annealing', total_gram: String(item.total_gram ?? ''), sisa_serbuk: '', catatan: '' }) }}
                  className="text-[11px] font-semibold px-3 h-7 bg-violet-50 text-violet-700 rounded-lg hover:bg-violet-100">
                  Update Status
                </button>
                {expanded === item.id ? <ChevronUp size={15} className="text-slate-400" /> : <ChevronDown size={15} className="text-slate-400" />}
              </div>
            </div>
            {expanded === item.id && item.produksi_event?.length > 0 && (
              <div className="px-4 pb-4 border-t border-slate-50 pt-3">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Histori Status</p>
                <div className="space-y-2">
                  {item.produksi_event.map((ev: any) => (
                    <div key={ev.id} className="flex items-center gap-3 text-xs">
                      <span className={cn('px-2 py-0.5 rounded-full font-semibold border text-[10px]', STATUS_BADGE_STYLES[ev.status as StatusProduksi] ?? '')}>{ev.status}</span>
                      <span className="text-slate-400">{formatDate(ev.tanggal)}</span>
                      {ev.total_gram && <span className="text-slate-600">{ev.total_gram} gr</span>}
                      {ev.catatan && <span className="text-slate-400 italic">{ev.catatan}</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Update Status Modal */}
      {showUpdateModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl">
            <h3 className="font-bold text-slate-800 mb-1">Update Status Produksi</h3>
            <p className="text-xs text-slate-400 mb-4">{showUpdateModal.kode}</p>
            <div className="space-y-3">
              <div>
                <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Status Baru</label>
                <select value={updateForm.status} onChange={e => setUpdateForm({ ...updateForm, status: e.target.value as StatusProduksi })}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                  {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Total Berat (gr)</label>
                <input type="number" value={updateForm.total_gram} onChange={e => setUpdateForm({ ...updateForm, total_gram: e.target.value })}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
              </div>
              <div>
                <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Sisa Serbuk (gr)</label>
                <input type="number" value={updateForm.sisa_serbuk} onChange={e => setUpdateForm({ ...updateForm, sisa_serbuk: e.target.value })}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" placeholder="0.00" />
              </div>
              <div>
                <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Catatan</label>
                <input value={updateForm.catatan} onChange={e => setUpdateForm({ ...updateForm, catatan: e.target.value })}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" placeholder="Opsional..." />
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <button onClick={() => setShowUpdateModal(null)} className="flex-1 h-10 bg-slate-100 rounded-xl text-sm font-medium text-slate-600">Batal</button>
              <button onClick={handleUpdateStatus} disabled={loading} className="flex-1 h-10 bg-violet-600 text-white rounded-xl text-sm font-semibold disabled:opacity-50">
                {loading ? 'Menyimpan...' : 'Simpan'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
