'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Plus, Search, Store, X, Save } from 'lucide-react'
import { cn, formatDate } from '@/lib/utils'
import { STATUS_BADGE_STYLES } from '@/lib/utils'
import { GRAMASI_OPTIONS } from '@/lib/types/database'

export default function POCabangClient({ initialPO, cabang }: any) {
  const [po, setPO] = useState(initialPO)
  const [search, setSearch] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ toko: '', gramasi: '1', pcspo: '', customer: '', catatan: '' })
  const supabase = createClient()

  const filtered = po.filter((p: any) =>
    (p.toko ?? '').toLowerCase().includes(search.toLowerCase()) ||
    (p.gramasi ?? '').includes(search)
  )

  const handleSubmit = async () => {
    if (!form.toko || !form.pcspo) return
    setLoading(true)
    const { data, error } = await supabase.from('po_toko').insert({
      tanggal: new Date().toISOString().split('T')[0],
      toko: form.toko, gramasi: form.gramasi,
      pcspo: parseInt(form.pcspo), customer: form.customer || null,
      catatan: form.catatan, status_g: 'Belum Dikirim', status_t: 'Belum Sampai'
    }).select().single()
    if (!error && data) { setPO([data, ...po]); setShowForm(false) }
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari PO..."
            className="w-full pl-8 pr-3 h-9 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-violet-400" />
        </div>
        <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-2 h-9 px-4 bg-violet-600 text-white rounded-xl text-sm font-semibold">
          <Plus size={14} /> PO Baru
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl border border-violet-100 p-5">
          <div className="flex justify-between mb-4">
            <h3 className="font-bold text-slate-800">Purchase Order Cabang</h3>
            <button onClick={() => setShowForm(false)}><X size={16} className="text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Cabang / Toko *</label>
              <select value={form.toko} onChange={e => setForm({ ...form, toko: e.target.value })}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                <option value="">-- Pilih Cabang --</option>
                {cabang.map((c: any) => <option key={c.kode} value={c.kode}>{c.nama}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Gramasi</label>
              <select value={form.gramasi} onChange={e => setForm({ ...form, gramasi: e.target.value })}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                {GRAMASI_OPTIONS.map(g => <option key={g} value={g}>{g} gr</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Jumlah PCS *</label>
              <input type="number" value={form.pcspo} onChange={e => setForm({ ...form, pcspo: e.target.value })}
                placeholder="10" className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Customer (opsional)</label>
              <input value={form.customer} onChange={e => setForm({ ...form, customer: e.target.value })}
                placeholder="Nama customer" className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
            </div>
          </div>
          <button onClick={handleSubmit} disabled={loading}
            className="mt-4 flex items-center gap-2 h-10 px-5 bg-violet-600 text-white rounded-xl text-sm font-semibold disabled:opacity-50">
            <Save size={14} /> {loading ? 'Menyimpan...' : 'Buat PO'}
          </button>
        </div>
      )}

      <div className="space-y-2">
        {filtered.length === 0 && <div className="bg-white rounded-2xl border border-slate-100 py-16 text-center"><Store size={32} className="text-slate-200 mx-auto mb-3" /><p className="text-slate-400 text-sm">Belum ada PO</p></div>}
        {filtered.map((p: any) => (
          <div key={p.id} className="bg-white rounded-2xl border border-slate-100 px-4 py-3.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-sm text-slate-800">{p.toko}</span>
              <span className="text-xs font-semibold text-slate-600">{p.gramasi} gr × {p.pcspo} pcs</span>
              <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full border', STATUS_BADGE_STYLES[p.status_g as keyof typeof STATUS_BADGE_STYLES] ?? '')}>{p.status_g}</span>
              <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full border', STATUS_BADGE_STYLES[p.status_t as keyof typeof STATUS_BADGE_STYLES] ?? '')}>{p.status_t}</span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">{formatDate(p.tanggal)} {p.customer ? `· ${p.customer}` : ''}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
