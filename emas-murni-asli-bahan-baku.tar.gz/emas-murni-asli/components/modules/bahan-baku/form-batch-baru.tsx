'use client'

import { useState, useEffect } from 'react'
import { X, Calculator, Save, Loader2 } from 'lucide-react'
import { cn, formatRupiah } from '@/lib/utils'
import { createClient } from '@/lib/supabase/client'

interface Props {
  onSuccess: (batch: any) => void
  onCancel: () => void
  currentUser: any
}

interface BiayaTambahan {
  nama: string
  jumlah: number
}

export default function FormBatchBaru({ onSuccess, onCancel, currentUser }: Props) {
  const supabase = createClient()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Form fields
  const [supplier, setSupplier] = useState('')
  const [tanggal, setTanggal] = useState(new Date().toISOString().split('T')[0])
  const [beratPusat, setBeratPusat] = useState('')
  const [beratGudang, setBeratGudang] = useState('')
  const [hargaBeli, setHargaBeli] = useState('')
  const [catatan, setCatatan] = useState('')
  const [biayaTambahan, setBiayaTambahan] = useState<BiayaTambahan[]>([
    { nama: 'Biaya Logistik', jumlah: 0 }
  ])

  // HPP calculations
  const totalBiayaTambahan = biayaTambahan.reduce((s, b) => s + (b.jumlah || 0), 0)
  const totalHPP = (Number(hargaBeli) || 0) + totalBiayaTambahan
  const hppPerGram = Number(beratGudang) > 0 ? totalHPP / Number(beratGudang) : 0
  const selisih = (Number(beratPusat) || 0) - (Number(beratGudang) || 0)

  // Auto-generate kode batch
  const [kode, setKode] = useState('')
  useEffect(() => {
    const now = new Date()
    const year = now.getFullYear()
    const month = String(now.getMonth() + 1).padStart(2, '0')
    const rand = String(Math.floor(Math.random() * 9000) + 1000)
    setKode(`BCH/${year}/${month}${rand}`)
  }, [])

  const addBiaya = () => setBiayaTambahan([...biayaTambahan, { nama: '', jumlah: 0 }])
  const removeBiaya = (i: number) => setBiayaTambahan(biayaTambahan.filter((_, idx) => idx !== i))
  const updateBiaya = (i: number, field: 'nama' | 'jumlah', val: string | number) => {
    setBiayaTambahan(biayaTambahan.map((b, idx) => idx === i ? { ...b, [field]: val } : b))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!supplier || !beratGudang || !hargaBeli) {
      setError('Supplier, berat gudang, dan harga beli wajib diisi.')
      return
    }
    setLoading(true)
    setError(null)

    const payload = {
      kode,
      tanggal,
      supplier,
      bahan_dari_pusat: Number(beratPusat) || null,
      timbangan_akhir: Number(beratGudang),
      sisa_fisik: Number(beratGudang),
      harga_beli: Number(hargaBeli),
      hpp_gr: hppPerGram,
      biaya_tbh: biayaTambahan.filter((b) => b.nama && b.jumlah > 0),
      catatan: catatan || null,
      status: 'aktif',
      created_by: currentUser?.id ?? null,
    }

    const { data, error: err } = await supabase
      .from('batch')
      .insert(payload)
      .select('*, creator:created_by(name)')
      .single()

    if (err) {
      setError('Gagal menyimpan batch: ' + err.message)
      setLoading(false)
      return
    }

    // Audit log
    await supabase.from('audit_log').insert({
      user_id: currentUser?.id,
      user_name: currentUser?.name,
      user_role: currentUser?.role,
      action: 'CREATE',
      module: 'bahan_baku',
      record_key: kode,
      record_id: String(data.id),
      after_data: payload,
    })

    onSuccess(data)
  }

  return (
    <div className="bg-white rounded-2xl border border-violet-200 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-violet-50">
        <div>
          <h3 className="font-bold text-slate-800">Registrasi Batch Baru</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Kode otomatis: <span className="font-mono font-semibold text-violet-600">{kode}</span>
          </p>
        </div>
        <button onClick={onCancel} className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-white rounded-lg transition-all">
          <X size={16} />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        {/* Row 1: Supplier + Tanggal */}
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">
              Supplier <span className="text-red-500">*</span>
            </label>
            <input type="text" value={supplier} onChange={(e) => setSupplier(e.target.value)}
              placeholder="Nama supplier / sumber bahan"
              className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400 focus:bg-white" />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">Tanggal</label>
            <input type="date" value={tanggal} onChange={(e) => setTanggal(e.target.value)}
              className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400 focus:bg-white" />
          </div>
        </div>

        {/* Row 2: Berat */}
        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">
              Berat Pusat (gram)
            </label>
            <input type="number" step="0.01" value={beratPusat} onChange={(e) => setBeratPusat(e.target.value)}
              placeholder="0.00"
              className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400 focus:bg-white" />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">
              Berat Gudang (gram) <span className="text-red-500">*</span>
            </label>
            <input type="number" step="0.01" value={beratGudang} onChange={(e) => setBeratGudang(e.target.value)}
              placeholder="0.00"
              className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400 focus:bg-white" />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">Selisih</label>
            <div className={cn(
              'w-full h-10 px-3 rounded-xl text-sm flex items-center font-semibold border',
              selisih > 0.5 ? 'bg-red-50 border-red-200 text-red-600' :
              selisih < -0.5 ? 'bg-blue-50 border-blue-200 text-blue-600' :
              'bg-emerald-50 border-emerald-200 text-emerald-600'
            )}>
              {beratPusat && beratGudang ? `${selisih > 0 ? '+' : ''}${selisih.toFixed(2)} gr` : '-'}
            </div>
          </div>
        </div>

        {/* Harga Beli */}
        <div>
          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">
            Harga Beli (IDR) <span className="text-red-500">*</span>
          </label>
          <input type="number" value={hargaBeli} onChange={(e) => setHargaBeli(e.target.value)}
            placeholder="0"
            className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400 focus:bg-white" />
        </div>

        {/* Biaya Tambahan */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Biaya Tambahan</label>
            <button type="button" onClick={addBiaya}
              className="text-xs text-violet-600 hover:text-violet-700 font-semibold flex items-center gap-1">
              + Tambah
            </button>
          </div>
          <div className="space-y-2">
            {biayaTambahan.map((b, i) => (
              <div key={i} className="flex gap-2">
                <input type="text" value={b.nama} onChange={(e) => updateBiaya(i, 'nama', e.target.value)}
                  placeholder="Nama biaya (misal: ongkir)"
                  className="flex-1 h-9 px-3 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-violet-400" />
                <input type="number" value={b.jumlah || ''} onChange={(e) => updateBiaya(i, 'jumlah', Number(e.target.value))}
                  placeholder="0"
                  className="w-32 h-9 px-3 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-violet-400" />
                <button type="button" onClick={() => removeBiaya(i)}
                  className="w-9 h-9 flex items-center justify-center text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all">
                  <X size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Catatan */}
        <div>
          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">Catatan</label>
          <textarea value={catatan} onChange={(e) => setCatatan(e.target.value)}
            placeholder="Catatan tambahan, keterangan sertifikat, dll..."
            rows={2}
            className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400 focus:bg-white resize-none" />
        </div>

        {/* HPP Summary */}
        <div className="bg-violet-50 rounded-xl p-4 border border-violet-100">
          <div className="flex items-center gap-2 mb-3">
            <Calculator size={15} className="text-violet-600" />
            <p className="text-sm font-bold text-violet-800">Kalkulasi HPP</p>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-violet-600 font-medium">Harga Beli</p>
              <p className="text-sm font-bold text-slate-800 mt-0.5">{formatRupiah(Number(hargaBeli) || 0)}</p>
            </div>
            <div>
              <p className="text-xs text-violet-600 font-medium">+ Biaya Tambahan</p>
              <p className="text-sm font-bold text-slate-800 mt-0.5">{formatRupiah(totalBiayaTambahan)}</p>
            </div>
            <div>
              <p className="text-xs text-violet-600 font-medium">Total HPP</p>
              <p className="text-sm font-bold text-violet-700 mt-0.5">{formatRupiah(totalHPP)}</p>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-violet-200">
            <p className="text-xs text-violet-600 font-medium">HPP per Gram</p>
            <p className="text-xl font-bold text-violet-700 mt-0.5">
              {hppPerGram > 0 ? `${formatRupiah(hppPerGram)} / gr` : '-'}
            </p>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-xs text-red-600">{error}</div>
        )}

        {/* Actions */}
        <div className="flex gap-3 justify-end">
          <button type="button" onClick={onCancel}
            className="px-5 h-10 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-100 transition-all">
            Batal
          </button>
          <button type="submit" disabled={loading}
            className={cn('flex items-center gap-2 px-6 h-10 bg-violet-600 hover:bg-violet-700 text-white rounded-xl text-sm font-bold transition-all',
              loading && 'opacity-60 cursor-not-allowed')}>
            {loading ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
            Simpan & Rekonsiliasi
          </button>
        </div>
      </form>
    </div>
  )
}
