'use client'

import { useState } from 'react'
import { Lock, Unlock, ChevronDown, ChevronUp, AlertTriangle, Loader2, X } from 'lucide-react'
import { cn, formatDate, formatRupiah } from '@/lib/utils'
import { createClient } from '@/lib/supabase/client'

interface Props {
  batch: any
  canLock: boolean
  currentUser: any
  onUpdated: (batch: any) => void
}

export default function BatchCard({ batch, canLock, currentUser, onUpdated }: Props) {
  const supabase = createClient()
  const [expanded, setExpanded] = useState(false)
  const [showLockModal, setShowLockModal] = useState(false)
  const [locking, setLocking] = useState(false)
  const [lockReason, setLockReason] = useState('')

  const isLocked = batch.status === 'terkunci'
  const sisaPersen = batch.timbangan_akhir > 0
    ? (batch.sisa_fisik / batch.timbangan_akhir) * 100
    : 0

  const totalBiaya = (batch.biaya_tbh ?? []).reduce((s: number, b: any) => s + (b.jumlah || 0), 0)
  const totalHPP = (batch.harga_beli || 0) + totalBiaya

  const handleLockToggle = async () => {
    setLocking(true)
    const newStatus = isLocked ? 'aktif' : 'terkunci'

    const updatePayload: any = {
      status: newStatus,
      locked_at: isLocked ? null : new Date().toISOString(),
      locked_by: isLocked ? null : currentUser?.id,
      lock_reason: isLocked ? null : lockReason,
    }

    const { data, error } = await supabase
      .from('batch')
      .update(updatePayload)
      .eq('id', batch.id)
      .select('*, creator:created_by(name)')
      .single()

    if (!error && data) {
      await supabase.from('audit_log').insert({
        user_id: currentUser?.id,
        user_name: currentUser?.name,
        user_role: currentUser?.role,
        action: isLocked ? 'UNLOCK_BATCH' : 'LOCK_BATCH',
        module: 'bahan_baku',
        record_key: batch.kode,
        record_id: String(batch.id),
        reason: lockReason || null,
      })
      onUpdated(data)
    }

    setLocking(false)
    setShowLockModal(false)
    setLockReason('')
  }

  return (
    <>
      <div className={cn(
        'bg-white rounded-2xl border transition-all',
        isLocked ? 'border-amber-200' : 'border-slate-100 hover:border-violet-200'
      )}>
        {/* Card header - always visible */}
        <div
          className="flex items-center gap-4 p-4 cursor-pointer select-none"
          onClick={() => setExpanded(!expanded)}
        >
          {/* Avatar */}
          <div className={cn(
            'w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 font-bold text-sm',
            isLocked ? 'bg-amber-100 text-amber-700' : 'bg-violet-100 text-violet-700'
          )}>
            AU
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <p className="font-mono font-bold text-slate-800 text-sm">{batch.kode}</p>
              <span className={cn(
                'text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase tracking-wider',
                isLocked
                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                  : 'bg-emerald-50 text-emerald-700 border-emerald-200'
              )}>
                {isLocked ? '🔒 Terkunci' : '✅ Aktif'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {batch.supplier ?? '-'} · {formatDate(batch.tanggal)}
            </p>
          </div>

          {/* Sisa */}
          <div className="text-right flex-shrink-0 hidden sm:block">
            <p className="text-sm font-bold text-slate-700">
              {Number(batch.sisa_fisik ?? 0).toFixed(2)} gr
            </p>
            <p className="text-[10px] text-slate-400">
              dari {Number(batch.timbangan_akhir ?? 0).toFixed(2)} gr
            </p>
            {/* Progress bar */}
            <div className="w-24 h-1.5 bg-slate-100 rounded-full mt-1.5 overflow-hidden">
              <div
                className={cn('h-full rounded-full transition-all',
                  sisaPersen > 50 ? 'bg-emerald-500' : sisaPersen > 20 ? 'bg-amber-500' : 'bg-red-500')}
                style={{ width: `${Math.min(sisaPersen, 100)}%` }}
              />
            </div>
          </div>

          {/* Lock button */}
          {canLock && (
            <button
              onClick={(e) => { e.stopPropagation(); setShowLockModal(true) }}
              className={cn(
                'p-2 rounded-xl transition-all flex-shrink-0',
                isLocked
                  ? 'text-amber-500 hover:bg-amber-50'
                  : 'text-slate-400 hover:bg-slate-100 hover:text-slate-600'
              )}
              title={isLocked ? 'Buka Kunci Batch' : 'Kunci Batch'}
            >
              {isLocked ? <Lock size={15} /> : <Lock size={15} />}
            </button>
          )}

          {/* Expand arrow */}
          <div className="text-slate-300 flex-shrink-0">
            {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </div>
        </div>

        {/* Expanded detail */}
        {expanded && (
          <div className="border-t border-slate-100 px-4 pb-4 pt-3">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-50 rounded-xl p-3">
                <p className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider mb-1">Berat Pusat</p>
                <p className="text-sm font-bold text-slate-700">{Number(batch.bahan_dari_pusat ?? 0).toFixed(2)} gr</p>
              </div>
              <div className="bg-slate-50 rounded-xl p-3">
                <p className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider mb-1">Berat Gudang</p>
                <p className="text-sm font-bold text-slate-700">{Number(batch.timbangan_akhir ?? 0).toFixed(2)} gr</p>
              </div>
              <div className="bg-violet-50 rounded-xl p-3">
                <p className="text-[10px] text-violet-500 uppercase font-semibold tracking-wider mb-1">HPP per Gram</p>
                <p className="text-sm font-bold text-violet-700">{formatRupiah(batch.hpp_gr ?? 0)}</p>
              </div>
              <div className="bg-slate-50 rounded-xl p-3">
                <p className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider mb-1">Total HPP</p>
                <p className="text-sm font-bold text-slate-700">{formatRupiah(totalHPP)}</p>
              </div>
            </div>

            {/* Biaya tambahan */}
            {batch.biaya_tbh?.length > 0 && (
              <div className="mt-3">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Biaya Tambahan</p>
                <div className="flex gap-2 flex-wrap">
                  {batch.biaya_tbh.map((b: any, i: number) => (
                    <span key={i} className="text-xs bg-slate-100 text-slate-600 px-2.5 py-1 rounded-lg font-medium">
                      {b.nama}: {formatRupiah(b.jumlah)}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {batch.catatan && (
              <div className="mt-3 text-xs text-slate-500 bg-slate-50 rounded-xl px-3 py-2">
                📝 {batch.catatan}
              </div>
            )}

            {isLocked && batch.lock_reason && (
              <div className="mt-3 text-xs text-amber-700 bg-amber-50 rounded-xl px-3 py-2 border border-amber-200">
                🔒 Alasan kunci: {batch.lock_reason}
              </div>
            )}

            <p className="text-[10px] text-slate-300 mt-3">
              Dibuat oleh {batch.creator?.name ?? 'sistem'} · {formatDate(batch.created_at)}
            </p>
          </div>
        )}
      </div>

      {/* Lock/Unlock Modal */}
      {showLockModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center',
                isLocked ? 'bg-emerald-100' : 'bg-amber-100')}>
                {isLocked ? <Unlock size={18} className="text-emerald-600" /> : <Lock size={18} className="text-amber-600" />}
              </div>
              <div>
                <h3 className="font-bold text-slate-800">
                  {isLocked ? 'Buka Kunci Batch?' : 'Kunci & Tutup Batch?'}
                </h3>
                <p className="text-xs text-slate-400">{batch.kode}</p>
              </div>
              <button onClick={() => setShowLockModal(false)} className="ml-auto text-slate-400 hover:text-slate-600">
                <X size={16} />
              </button>
            </div>

            <div className={cn('rounded-xl p-3 mb-4 text-xs border',
              isLocked ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-amber-50 border-amber-200 text-amber-700')}>
              <AlertTriangle size={13} className="inline mr-1" />
              {isLocked
                ? 'Batch akan dibuka kembali dan bisa digunakan untuk produksi.'
                : 'Setelah dikunci, batch tidak bisa digunakan untuk produksi baru.'}
            </div>

            {!isLocked && (
              <div className="mb-4">
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">
                  Alasan Kunci (opsional)
                </label>
                <input type="text" value={lockReason} onChange={(e) => setLockReason(e.target.value)}
                  placeholder="Misal: Bahan habis terpakai, pindah batch baru..."
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
              </div>
            )}

            <div className="flex gap-3">
              <button onClick={() => setShowLockModal(false)}
                className="flex-1 h-10 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-100 transition-all border border-slate-200">
                Batal
              </button>
              <button onClick={handleLockToggle} disabled={locking}
                className={cn('flex-1 h-10 rounded-xl text-sm font-bold text-white transition-all flex items-center justify-center gap-2',
                  isLocked ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-amber-600 hover:bg-amber-700',
                  locking && 'opacity-60 cursor-not-allowed')}>
                {locking ? <Loader2 size={14} className="animate-spin" /> :
                  isLocked ? <><Unlock size={14} /> Buka Kunci</> : <><Lock size={14} /> Ya, Kunci Batch</>}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
