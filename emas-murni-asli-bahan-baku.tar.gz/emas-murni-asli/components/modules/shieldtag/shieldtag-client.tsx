'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Search, Tag, Plus, X, Save } from 'lucide-react'
import { cn, formatDate } from '@/lib/utils'
import { STATUS_BADGE_STYLES } from '@/lib/utils'
import type { Shieldtag, StatusShieldtag } from '@/lib/types/database'
import { GRAMASI_OPTIONS } from '@/lib/types/database'

export default function ShieldtagClient({ initialTags }: { initialTags: Shieldtag[] }) {
  const [tags, setTags] = useState<Shieldtag[]>(initialTags)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('semua')
  const [showForm, setShowForm] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ kode: '', gramasi: '1', batch_kode: '', hpp: '' })
  const supabase = createClient()

  const filtered = tags.filter(t => {
    const matchSearch = t.kode.toLowerCase().includes(search.toLowerCase()) ||
      (t.gramasi ?? '').includes(search) || (t.batch_kode ?? '').toLowerCase().includes(search.toLowerCase())
    const matchStatus = statusFilter === 'semua' || t.status === statusFilter
    return matchSearch && matchStatus
  })

  const handleSubmit = async () => {
    if (!form.kode || !form.gramasi) return
    setLoading(true)
    const { data, error } = await supabase.from('shieldtag').insert({
      kode: form.kode, gramasi: form.gramasi,
      batch_kode: form.batch_kode || null,
      hpp: parseFloat(form.hpp) || null,
      status: 'Aktif' as StatusShieldtag,
      tgl_regis: new Date().toISOString().split('T')[0]
    }).select().single()
    if (!error && data) { setTags([data, ...tags]); setShowForm(false); setForm({ kode: '', gramasi: '1', batch_kode: '', hpp: '' }) }
    setLoading(false)
  }

  const statuses: StatusShieldtag[] = ['Aktif', 'Terdistribusi', 'Terjual', 'VOID']

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari kode, gramasi, batch..."
            className="w-full pl-8 pr-3 h-9 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-violet-400" />
        </div>
        <div className="flex gap-1">
          {['semua', ...statuses].map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={cn('px-2.5 h-8 rounded-lg text-[11px] font-semibold transition-all',
                statusFilter === s ? 'bg-violet-600 text-white' : 'bg-white text-slate-600 border border-slate-200')}>
              {s === 'semua' ? 'Semua' : s}
            </button>
          ))}
        </div>
        <button onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 h-9 px-4 bg-violet-600 text-white rounded-xl text-sm font-semibold ml-auto">
          <Plus size={14} /> Registrasi Manual
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl border border-violet-100 p-5">
          <div className="flex justify-between mb-4">
            <h3 className="font-bold text-slate-800">Registrasi Shieldtag Manual</h3>
            <button onClick={() => setShowForm(false)}><X size={16} className="text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Kode Shieldtag *', key: 'kode', placeholder: 'SHT-2026-00001' },
              { label: 'Batch Asal', key: 'batch_kode', placeholder: 'BCH/2026/05001' },
              { label: 'HPP (IDR)', key: 'hpp', placeholder: '950000' },
            ].map(f => (
              <div key={f.key}>
                <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">{f.label}</label>
                <input value={(form as any)[f.key]} onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                  placeholder={f.placeholder}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" />
              </div>
            ))}
            <div>
              <label className="text-[10px] font-semibold text-slate-500 uppercase block mb-1">Gramasi *</label>
              <select value={form.gramasi} onChange={e => setForm({ ...form, gramasi: e.target.value })}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                {GRAMASI_OPTIONS.map(g => <option key={g} value={g}>{g} gr</option>)}
              </select>
            </div>
          </div>
          <button onClick={handleSubmit} disabled={loading}
            className="mt-4 flex items-center gap-2 h-10 px-5 bg-violet-600 text-white rounded-xl text-sm font-semibold disabled:opacity-50">
            <Save size={14} /> {loading ? 'Menyimpan...' : 'Simpan Shieldtag'}
          </button>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-100 bg-slate-50/50">
              <tr>
                {['Kode', 'Gramasi', 'Batch', 'Status', 'Lokasi', 'Tgl Registrasi', 'HPP'].map(h => (
                  <th key={h} className="text-left px-4 py-2.5 text-[10px] font-bold text-slate-500 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={7} className="text-center py-12 text-slate-300 text-sm">
                  <Tag size={28} className="mx-auto mb-2 opacity-30" />Belum ada shieldtag
                </td></tr>
              )}
              {filtered.map(tag => (
                <tr key={tag.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                  <td className="px-4 py-2.5 font-mono text-xs font-semibold text-slate-700">{tag.kode}</td>
                  <td className="px-4 py-2.5 font-bold text-slate-800">{tag.gramasi} gr</td>
                  <td className="px-4 py-2.5 text-xs text-slate-500">{tag.batch_kode ?? '-'}</td>
                  <td className="px-4 py-2.5">
                    <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full border', STATUS_BADGE_STYLES[tag.status] ?? '')}>
                      {tag.status}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-xs text-slate-500">{tag.lokasi ?? 'Gudang Pusat'}</td>
                  <td className="px-4 py-2.5 text-xs text-slate-400">{formatDate(tag.tgl_regis)}</td>
                  <td className="px-4 py-2.5 text-xs text-slate-600">{tag.hpp ? `Rp ${Number(tag.hpp).toLocaleString('id-ID')}` : '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
