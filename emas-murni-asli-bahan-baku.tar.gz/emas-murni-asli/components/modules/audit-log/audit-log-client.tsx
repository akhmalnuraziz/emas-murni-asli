'use client'
import { useState } from 'react'
import { Search, ScrollText } from 'lucide-react'
import { formatDateTime } from '@/lib/utils'

export default function AuditLogClient({ initialLogs }: { initialLogs: any[] }) {
  const [search, setSearch] = useState('')
  const [moduleFilter, setModuleFilter] = useState('semua')

  const modules = ['semua', ...Array.from(new Set(initialLogs.map(l => l.module))).filter(Boolean)]

  const filtered = initialLogs.filter(l => {
    const matchSearch = (l.action ?? '').toLowerCase().includes(search.toLowerCase()) ||
      (l.user_name ?? '').toLowerCase().includes(search.toLowerCase()) ||
      (l.record_key ?? '').toLowerCase().includes(search.toLowerCase())
    const matchModule = moduleFilter === 'semua' || l.module === moduleFilter
    return matchSearch && matchModule
  })

  const ACTION_COLORS: Record<string, string> = {
    CREATE: 'bg-green-50 text-green-700', UPDATE: 'bg-blue-50 text-blue-700',
    DELETE: 'bg-red-50 text-red-600', LOCK: 'bg-amber-50 text-amber-700',
    LOGIN: 'bg-violet-50 text-violet-700',
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari action, user, record..."
            className="w-full pl-8 pr-3 h-9 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-violet-400" />
        </div>
        <div className="flex gap-1 flex-wrap">
          {modules.slice(0, 8).map(m => (
            <button key={m} onClick={() => setModuleFilter(m)}
              className={`px-2.5 h-8 rounded-lg text-[11px] font-semibold capitalize transition-all ${moduleFilter === m ? 'bg-violet-600 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>
              {m}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-100 bg-slate-50/50">
              <tr>
                {['Waktu', 'User', 'Role', 'Modul', 'Action', 'Record'].map(h => (
                  <th key={h} className="text-left px-4 py-2.5 text-[10px] font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="text-center py-12 text-slate-300">
                  <ScrollText size={28} className="mx-auto mb-2 opacity-30" />Belum ada log
                </td></tr>
              )}
              {filtered.map((log: any) => (
                <tr key={log.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                  <td className="px-4 py-2.5 text-xs text-slate-400 whitespace-nowrap">{formatDateTime(log.timestamp)}</td>
                  <td className="px-4 py-2.5 text-sm font-medium text-slate-800">{log.user_name || '-'}</td>
                  <td className="px-4 py-2.5 text-xs text-slate-500 capitalize">{log.user_role || '-'}</td>
                  <td className="px-4 py-2.5"><span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">{log.module}</span></td>
                  <td className="px-4 py-2.5">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${ACTION_COLORS[log.action] ?? 'bg-slate-100 text-slate-600'}`}>{log.action}</span>
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs text-slate-500">{log.record_key || log.record_id || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
